# Isletim-Sistemleri-17.Grup
G191210079 Safa Batuhan Akdemir ------ G191210049 Engin Sirkeoğlu ------ G181210553 Engin Özlem ------ G191210385 İbrahim Yiğit Tın ------ G191210064 Fatih Durmaz 