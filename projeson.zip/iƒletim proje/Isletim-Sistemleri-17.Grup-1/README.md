# Isletim-Sistemleri-17.Grup
G191210079 Safa Batuhan Akdemir ------ G191210049 Engin Sirkeoğlu ------ G181210553 Engin Özlem ------ G191210385 İbrahim Yiğit Tın ------ G191210064 Fatih Durmaz 
# Dosyalar
> main.c
* main.c İçersinde proje içerisinde kullanılan struct ve metodları barındırır. Kullanıcı tarafından girilen komutları parçalama işlemleri,fork ve execvp vb. komutlar gerçekleştirilir.
# Derleme
> gcc main.c -o main
* Çalıştırma Talimatları
> ./main
* Program İçindeki Kodların Çalıştırılması
> Programı sonlandırmak için --> exit kullanılır.
* Konum değişikliği için
> cd< gitmek istenilen dizin >
* 5 tane prosesin pid değerlerni ekrana yazmak için
> showpid
* execvp kullanarak ls komutunu çalıştırmak için
> ls
* Proje Sırasında Karşılaştığımız Zorluklar
> Sanal makine ile Linux kullanmayı öğrenmek
> Girilen komutları parçalara ayırıp buna göre işlem yapmak
# Kullanılan Kaynaklar
* Stackoverflow
* Geeksforgeeks
